<?php
include('../includes/pdoconfig.php');

if (!empty($_POST["roomid"])) {
    // Get number of seaters in the selected room
    $id = $_POST['roomid'];
    $stmt = $DB_con->prepare("SELECT seater FROM rooms WHERE room_no = :id");
    $stmt->execute([':id' => $id]);

    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo htmlentities($row['seater']);
    } else {
        echo "0";
    }
}

if (!empty($_POST["rid"])) {
    // Get fees for the selected room
    $id = $_POST['rid'];
    $stmt = $DB_con->prepare("SELECT fees FROM rooms WHERE room_no = :id");
    $stmt->execute([':id' => $id]);

    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo htmlentities($row['fees']); // e.g., ₦45000
    } else {
        echo "0";
    }
}
?>
