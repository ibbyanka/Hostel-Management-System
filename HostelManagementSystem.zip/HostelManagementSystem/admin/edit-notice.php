<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include('../includes/dbconn.php');
include('../includes/check-login.php');
check_login();

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "<script>alert('Invalid notice ID!'); window.location='notice.php';</script>";
    exit();
}

$noticeId = intval($_GET['id']);

// Handle form submission
if (isset($_POST['update'])) {
    $title = trim($_POST['title']);
    $message = trim($_POST['message']);

    if (!empty($title) && !empty($message)) {
        $stmt = $mysqli->prepare("UPDATE notice SET title = ?, message = ? WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("ssi", $title, $message, $noticeId);
            if ($stmt->execute()) {
                echo "<script>alert('Notice updated successfully!'); window.location='notice.php';</script>";
                exit();
            } else {
                echo "<script>alert('Execute error: " . $stmt->error . "');</script>";
            }
        } else {
            echo "<script>alert('Prepare failed: " . $mysqli->error . "');</script>";
        }
    } else {
        echo "<script>alert('All fields are required!');</script>";
    }
}

// Fetch existing notice data
$stmt = $mysqli->prepare("SELECT title, message FROM notice WHERE id = ?");
$stmt->bind_param("i", $noticeId);
$stmt->execute();
$stmt->bind_result($title, $message);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
    <meta charset="utf-8">
    <title>Edit Notice - Hostel Management System</title>
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/favicon.png">
    <link href="../assets/extra-libs/c3/c3.min.css" rel="stylesheet">
    <link href="../assets/libs/chartist/dist/chartist.min.css" rel="stylesheet">
    <link href="../dist/css/style.min.css" rel="stylesheet">
</head>
<body>
    <div class="preloader">
        <div class="lds-ripple"><div class="lds-pos"></div><div class="lds-pos"></div></div>
    </div>

    <div id="main-wrapper" data-theme="light" data-layout="vertical" data-navbarbg="skin6"
        data-sidebartype="full" data-sidebar-position="fixed" data-header-position="fixed" data-boxed-layout="full">

        <!-- Topbar -->
        <header class="topbar" data-navbarbg="skin6">
            <?php include 'includes/navigation.php'; ?>
        </header>

        <!-- Sidebar -->
        <aside class="left-sidebar" data-sidebarbg="skin6">
            <div class="scroll-sidebar" data-sidebarbg="skin6">
                <?php include 'includes/sidebar.php'; ?>
            </div>
        </aside>

        <!-- Page wrapper -->
        <div class="page-wrapper">
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 align-self-center">
                        <h4 class="page-title text-dark font-weight-medium">Edit Notice</h4>
                    </div>
                </div>
            </div>

            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="form-group">
                                <label for="title">Notice Title</label>
                                <input type="text" name="title" id="title" class="form-control" value="<?php echo htmlspecialchars($title); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="message">Notice Message</label>
                                <textarea name="message" id="message" class="form-control" rows="5" required><?php echo htmlspecialchars($message); ?></textarea>
                            </div>

                            <button type="submit" name="update" class="btn btn-warning">Update</button>
                            <a href="notice.php" class="btn btn-secondary">Cancel</a>
                        </form>
                    </div>
                </div>
            </div>

            <?php include '../includes/footer.php'; ?>
        </div>
    </div>

    <!-- Scripts -->
    <script src="../assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../dist/js/app-style-switcher.js"></script>
    <script src="../dist/js/feather.min.js"></script>
    <script src="../assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="../dist/js/sidebarmenu.js"></script>
    <script src="../dist/js/custom.min.js"></script>
</body>
</html>
