<?php
session_start();
include('../includes/dbconn.php');
include('../includes/check-login.php');
check_login();

$id = intval($_GET['id']);

$stmt = $mysqli->prepare("DELETE FROM notice WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();

echo "<script>alert('Notice deleted successfully!'); window.location='notice.php';</script>";
?>
